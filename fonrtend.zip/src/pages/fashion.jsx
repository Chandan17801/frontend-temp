import React from 'react'

const fashion = () => {
  return (
    <div>fashion</div>
  )
}

export default fashion