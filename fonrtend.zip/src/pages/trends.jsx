import React from 'react'

const trends = () => {
  return (
    <div>trends</div>
  )
}

export default trends