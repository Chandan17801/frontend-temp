import React from 'react';
import { IoSettingsSharp, IoPersonSharp, IoNotificationsSharp, IoHelpSharp } from 'react-icons/io5';

function Settingpage() {
    return (
        <div>
            <div className='flex'>
                {/* Sidebar */}
                {/* <div className='left' style={{
                    width: '334px',
                    height: '2449px',
                    top: '117px',
                    left: '-26px',
                    backgroundColor: 'rgba(214, 203, 107, 0.16)'
                }}>
                    <ul className="sidebar">
                        <li><IoSettingsSharp /> Main Setting</li>
                        <li><IoPersonSharp /> Edit Profile</li>
                        <li><IoNotificationsSharp /> Notification Appearance</li>
                        <li><IoHelpSharp /> Help</li>
                    </ul>
                </div> */}

                <div className='w-20 ' style={{ width: '20%', height: '500px', backgroundColor: 'rgba(214, 203, 107, 0.16)' }}>
                    <div className='flex flex-col gap-7 h-full p-4' style={{
                        width: "80%", margin: "auto", color: '#000',
                        fontFamily: 'Podkova',
                        fontSize: '20px',
                        fontStyle: 'normal',
                        fontWeight: '400',
                        lineHeight: 'normal'
                    }}>
                        <div className='text-[-#000] flex items-center space-x-2'>

                            <a href='#'> Setting</a>
                        </div>
                        <div className='text-[-#000] flex items-center space-x-2'>
                            <IoPersonSharp />
                            <a href='#'>Edit Profile</a>
                        </div>
                        <div className='text-[-#000] flex items-center space-x-2'>
                            <IoNotificationsSharp />
                            <a href='#'>Notification </a>
                        </div>

                        <div className='text-[-#000] flex items-center space-x-2'>
                            <IoSettingsSharp />
                            <a href='#'>Apperence</a>
                        </div>
                        <div className='text-[-#000] flex items-center space-x-2'>
                            <IoHelpSharp />
                            <a href='#'>Help</a>
                        </div>



                    </div>
                </div>







                {/* Main Content */}
                <div className='right'>
                    <form className='p-4 flex flex-col'>
                        <h2>Edit Profile</h2>

                        <div className="flex items-center gap-5">
                            <div className="flex-grow">
                                <label htmlFor='firstName'>First Name:</label> <br />
                                <input type='text' id='firstName' name='firstName' className="border-b" />
                            </div>
                            <div className="flex-grow">
                                <label htmlFor='lastName'>Last Name:</label> <br />
                                <input type='text' id='lastName' name='lastName' className="border-b" />
                            </div>
                        </div>

                        <label htmlFor='email'>Email:</label> <br />
                        <input type='email' id='email' name='email' className="border-b" />

                        <label htmlFor='bio'>Address:</label>
                        <textarea id='bio' name='bio' className="border-b"></textarea>
                        <div className="flex items-center gap-5">
                            <div className="flex-grow">
                                <label htmlFor='firstName'>Contact Number:</label> <br />
                                <input type='text' id='firstName' name='firstName' className="border-b" />
                            </div>
                            <div className="flex-grow">

                                <input type='text' id='lastName' value="optional" name='lastName' className="border-b mt-5" />
                            </div>
                        </div>
                        <div className="flex items-center gap-5">
                            <div className="flex-grow">
                                <label htmlFor='city'>City:</label> <br />
                                <select id='city' name='city' className="border-b mt-5">
                                    <option value="">Select Your City</option>
                                    <option value="city1">City 1</option>
                                    <option value="city2">City 2</option>
                                    {/* Add more city options */}
                                </select>
                            </div>
                            <div className="flex-grow gap-5">
                                <label htmlFor='state'>State:</label> <br />
                                <select id='state' name='state' className="border-b   mt-5">
                                    <option value="">Select Your State</option>
                                    <option value="state1">State 1</option>
                                    <option value="state2">State 2</option>
                                    {/* Add more state options */}
                                </select>
                            </div>
                        </div>
                        <div className="flex items-center gap-5 mt-5">
                            <div className="flex-grow">
                                <label htmlFor=''>Password:</label> <br />
                                <input type='password' id='password' name='password' className="border-b" />
                            </div>
                            <div className="flex-grow">
                                <label htmlFor='password'>Confirm Password:</label> <br />
                                <input type='password' id='password' name='password' className="border-b" />
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    )
}

export default Settingpage;
