import React from 'react'

const premium_collection = () => {
  return (
    <div>premium_collection</div>
  )
}

export default premium_collection