import React from 'react'
import Cartpage from '@/components/cart_page/Cartpage'
import Settingpage from '@/components/setting/Settingpage'
const mordrest = () => {
  return (
    <div>
    <Settingpage/>
    </div>
  )
}

export default mordrest